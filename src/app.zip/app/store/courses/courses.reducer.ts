import { Action } from '@ngrx/store';

// Add your code here

export interface CoursesState {
    // Add your code here
}

export const initialState: CoursesState = {
    // Add your code here
};

export const coursesReducer; // Add your code here

export const reducer = (state: CoursesState, action: Action): CoursesState => coursesReducer(state, action);
