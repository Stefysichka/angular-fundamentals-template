import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class CoursesStateFacade {
    // Add your code here
}
