import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

const API_URL = 'http://localhost:4000/api';

export interface Author {
  id: string;
  name: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  creationDate: string | Date;
  duration: number;
  authors: string[]; 
}

export interface CreateCourseDto {
  title: string;
  description: string;
  duration: number;
  authors: string[];
}

@Injectable({
  providedIn: 'root'
})
export class CoursesService {
  constructor(private http: HttpClient) {}

  getAll(opts?: { start?: number; count?: number; text?: string }): Observable<Course[]> {
    let params = new HttpParams();
    if (opts?.start != null) params = params.set('start', String(opts.start));
    if (opts?.count != null) params = params.set('count', String(opts.count));
    if (opts?.text) params = params.set('text', opts.text);
    return this.http.get<Course[]>(`${API_URL}/courses`, { params });
  }

  getCourse(id: string): Observable<Course> {
    return this.http.get<Course>(`${API_URL}/courses/${id}`);
  }

  createCourse(course: CreateCourseDto): Observable<Course> {
    return this.http.post<Course>(`${API_URL}/courses`, course);
  }

  editCourse(id: string, course: CreateCourseDto): Observable<Course> {
    return this.http.put<Course>(`${API_URL}/courses/${id}`, course);
  }

  deleteCourse(id: string): Observable<void> {
    return this.http.delete<void>(`${API_URL}/courses/${id}`);
  }

  filterCourses(text: string, opts?: { start?: number; count?: number }): Observable<Course[]> {
    return this.getAll({ ...opts, text });
  }

  getAllAuthors(): Observable<Author[]> {
    return this.http.get<Author[]>(`${API_URL}/authors`);
  }

  getAuthorById(id: string): Observable<Author> {
    return this.http.get<Author>(`${API_URL}/authors/${id}`);
  }

  createAuthor(name: string): Observable<Author> {
    return this.http.post<Author>(`${API_URL}/authors`, { name });
  }
}
